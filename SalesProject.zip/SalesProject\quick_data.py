# QUICK DATA GENERATOR
import pandas as pd
import numpy as np

# Set random seed
np.random.seed(42)

# Create sample data (1000 rows)
data = []
for i in range(1000):
    month = np.random.randint(1, 7)
    day = np.random.randint(1, 29)
    data.append({
        'Date': f'2023-{month:02d}-{day:02d}',
        'Product': np.random.choice(['Laptop', 'Phone', 'Tablet', 'Headphones']),
        'Region': np.random.choice(['North', 'South', 'East', 'West']),
        'Quantity': np.random.randint(1, 5),
        'Price': np.random.choice([799, 999, 499, 299]),
        'Total_Sales': np.random.randint(1, 5) * np.random.choice([799, 999, 499, 299])
    })

# Create DataFrame
df = pd.DataFrame(data)

# Save to CSV
import os
os.makedirs('data', exist_ok=True)
df.to_csv('data/sales_data.csv', index=False)

print(f"✅ Created {len(df)} records")
print(f"📊 Sample data:")
print(df.head())