import pandas as pd

# Load data
df = pd.read_csv('data/sales_data.csv')

# Check what columns we have
print("Current columns:", list(df.columns))

# If column is 'Total' but should be 'Total_Sales'
if 'Total' in df.columns and 'Total_Sales' not in df.columns:
    df.rename(columns={'Total': 'Total_Sales'}, inplace=True)
    print("✓ Renamed 'Total' to 'Total_Sales'")

# If column is 'Sales' but should be 'Total_Sales'  
if 'Sales' in df.columns and 'Total_Sales' not in df.columns:
    df.rename(columns={'Sales': 'Total_Sales'}, inplace=True)
    print("✓ Renamed 'Sales' to 'Total_Sales'")

# Save back
df.to_csv('data/sales_data.csv', index=False)
print("✓ Data saved with corrected column names")
print("\nUpdated columns:", list(df.columns))