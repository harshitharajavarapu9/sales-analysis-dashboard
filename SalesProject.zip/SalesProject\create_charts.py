"""
CREATE CHARTS for Sales Analysis Dashboard
Creates visualizations of sales data
"""

import pandas as pd
import numpy as np
import os

print("📈 Creating sales charts and reports...")

try:
    # Load data
    df = pd.read_csv('data/sales_data.csv')
    df['Date'] = pd.to_datetime(df['Date'])
    
    # Create outputs folder
    os.makedirs('outputs/charts', exist_ok=True)
    
    print("✅ Data loaded successfully")
    print(f"   Records: {len(df):,}")
    print(f"   Total Sales: ${df['Total_Sales'].sum():,.2f}")
    print()
    
    # 1. Monthly Sales Analysis
    print("1. Generating Monthly Sales Analysis...")
    df['Month'] = df['Date'].dt.month_name()
    monthly_sales = df.groupby('Month')['Total_Sales'].sum()
    
    # Save monthly data
    monthly_sales.to_csv('outputs/monthly_sales_detailed.csv')
    print("   ✓ Saved: outputs/monthly_sales_detailed.csv")
    
    # Create text chart for monthly sales
    print("\n   📊 MONTHLY SALES TREND (Text Chart):")
    print("   " + "-" * 50)
    max_sales = monthly_sales.max()
    for month, sales in monthly_sales.items():
        bars = "█" * int(sales / max_sales * 40)
        print(f"   {month:9s}: ${sales:9,.2f} {bars}")
    
    # 2. Product Analysis
    print("\n2. Generating Product Analysis...")
    product_sales = df.groupby('Product').agg({
        'Quantity': 'sum',
        'Total_Sales': 'sum'
    }).sort_values('Total_Sales', ascending=False)
    
    product_sales.to_csv('outputs/product_analysis.csv')
    print("   ✓ Saved: outputs/product_analysis.csv")
    
    print("\n   📦 TOP PRODUCTS (Text Chart):")
    print("   " + "-" * 50)
    max_product_sales = product_sales['Total_Sales'].max()
    for product, row in product_sales.iterrows():
        bars = "█" * int(row['Total_Sales'] / max_product_sales * 40)
        print(f"   {product:12s}: ${row['Total_Sales']:9,.2f} {bars}")
    
    # 3. Regional Analysis
    print("\n3. Generating Regional Analysis...")
    region_sales = df.groupby('Region')['Total_Sales'].sum().sort_values(ascending=False)
    
    region_sales.to_csv('outputs/regional_analysis.csv')
    print("   ✓ Saved: outputs/regional_analysis.csv")
    
    print("\n   🌍 REGIONAL SALES (Text Chart):")
    print("   " + "-" * 50)
    max_region_sales = region_sales.max()
    for region, sales in region_sales.items():
        bars = "█" * int(sales / max_region_sales * 40)
        print(f"   {region:12s}: ${sales:9,.2f} {bars}")
    
    # 4. Create Summary Report
    print("\n4. Creating Summary Report...")
    with open('outputs/sales_summary.txt', 'w') as f:
        f.write("=" * 60 + "\n")
        f.write("SALES ANALYSIS SUMMARY REPORT\n")
        f.write("=" * 60 + "\n\n")
        
        f.write(f"Report Date: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')}\n")
        f.write(f"Total Records: {len(df):,}\n")
        f.write(f"Total Sales: ${df['Total_Sales'].sum():,.2f}\n")
        f.write(f"Date Range: {df['Date'].min().date()} to {df['Date'].max().date()}\n\n")
        
        f.write("MONTHLY SALES:\n")
        f.write("-" * 40 + "\n")
        for month, sales in monthly_sales.items():
            f.write(f"{month:9s}: ${sales:12,.2f}\n")
        
        f.write("\nTOP PRODUCTS:\n")
        f.write("-" * 40 + "\n")
        for product, row in product_sales.iterrows():
            f.write(f"{product:12s}: ${row['Total_Sales']:12,.2f} ({row['Quantity']} units)\n")
        
        f.write("\nREGIONAL SALES:\n")
        f.write("-" * 40 + "\n")
        for region, sales in region_sales.items():
            f.write(f"{region:12s}: ${sales:12,.2f}\n")
    
    print("   ✓ Saved: outputs/sales_summary.txt")
    
    # 5. Try to create matplotlib charts if available
    try:
        import matplotlib.pyplot as plt
        print("\n5. Attempting to create graphical charts...")
        
        # Create a simple bar chart
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        
        # Monthly sales bar chart
        months = monthly_sales.index.tolist()
        sales_vals = monthly_sales.values.tolist()
        
        bars1 = ax1.bar(months, sales_vals, color=['#4CAF50', '#2196F3', '#FF9800', '#9C27B0', '#E91E63', '#00BCD4'])
        ax1.set_title('Monthly Sales Trend', fontweight='bold')
        ax1.set_xlabel('Month')
        ax1.set_ylabel('Total Sales ($)')
        ax1.tick_params(axis='x', rotation=45)
        
        # Add value labels on bars
        for bar in bars1:
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height + max(sales_vals)*0.01,
                    f'${height:,.0f}', ha='center', va='bottom', fontsize=8)
        
        # Product sales horizontal bar chart
        products = product_sales.index.tolist()
        product_vals = product_sales['Total_Sales'].tolist()
        
        bars2 = ax2.barh(products, product_vals, color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4'])
        ax2.set_title('Sales by Product', fontweight='bold')
        ax2.set_xlabel('Total Sales ($)')
        
        plt.tight_layout()
        plt.savefig('outputs/charts/sales_analysis.png', dpi=150, bbox_inches='tight')
        plt.close()
        
        print("   ✓ Created: outputs/charts/sales_analysis.png (graphical chart)")
        
    except ImportError:
        print("   ℹ️  Matplotlib not available. Text charts created instead.")
    except Exception as e:
        print(f"   ⚠️  Could not create graphical charts: {e}")
    
    print("\n" + "=" * 60)
    print("✅ ALL CHARTS AND REPORTS CREATED SUCCESSFULLY!")
    print("=" * 60)
    print("\n📁 Output files created in 'outputs/' folder:")
    print("   - monthly_sales_detailed.csv")
    print("   - product_analysis.csv")
    print("   - regional_analysis.csv")
    print("   - sales_summary.txt")
    print("   - charts/sales_analysis.png (if matplotlib available)")
    
except FileNotFoundError:
    print("❌ ERROR: data/sales_data.csv not found!")
    print("Run 'python quick_data.py' first to create the data")
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()