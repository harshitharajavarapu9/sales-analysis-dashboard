import pandas as pd
import numpy as np
import os

print("📊 SIMPLE SALES ANALYSIS")
print("=" * 40)

try:
    # Load data
    df = pd.read_csv('data/sales_data.csv')
    
    # Check what columns we have
    print(f"\n📋 Columns found: {list(df.columns)}")
    
    # Convert Date if it exists
    if 'Date' in df.columns:
        df['Date'] = pd.to_datetime(df['Date'])
    
    print(f"\n1. Total Records: {len(df):,}")
    
    if 'Date' in df.columns:
        print(f"2. Date Range: {df['Date'].min().date()} to {df['Date'].max().date()}")
    
    # Check which sales column exists
    sales_column = None
    for col in ['Total_Sales', 'Total', 'Sales', 'Amount']:
        if col in df.columns:
            sales_column = col
            break
    
    if sales_column:
        total_sales = df[sales_column].sum()
        print(f"3. Total Sales: ${total_sales:,.2f}")
        
        print("\n4. Monthly Sales Trend:")
        if 'Date' in df.columns:
            df['Month'] = df['Date'].dt.month_name()
            monthly = df.groupby('Month')[sales_column].sum()
            for month, sales in monthly.items():
                print(f"   {month}: ${sales:,.2f}")
        else:
            print("   (No Date column for monthly analysis)")
        
        print("\n5. Best-Selling Products:")
        if 'Product' in df.columns:
            products = df.groupby('Product').agg({'Quantity': 'sum', sales_column: 'sum'})
            products = products.sort_values(sales_column, ascending=False)
            for product, row in products.iterrows():
                print(f"   {product}: {row['Quantity']} units (${row[sales_column]:,.2f})")
        else:
            print("   (No Product column)")
        
        print("\n6. Region-wise Sales:")
        if 'Region' in df.columns:
            regions = df.groupby('Region')[sales_column].sum()
            regions = regions.sort_values(ascending=False)
            for region, sales in regions.items():
                print(f"   {region}: ${sales:,.2f}")
        else:
            print("   (No Region column)")
        
        # Save analysis to CSV
        os.makedirs('outputs', exist_ok=True)
        
        if 'Date' in df.columns and 'Month' in df.columns:
            monthly.to_csv('outputs/monthly_sales.csv')
            print("   ✓ Saved: outputs/monthly_sales.csv")
        
        if 'Product' in df.columns:
            products.to_csv('outputs/product_sales.csv')
            print("   ✓ Saved: outputs/product_sales.csv")
        
        if 'Region' in df.columns:
            regions.to_csv('outputs/region_sales.csv')
            print("   ✓ Saved: outputs/region_sales.csv")
        
        print("\n✅ Analysis complete!")
        
    else:
        print("❌ No sales amount column found!")
        
except FileNotFoundError:
    print("❌ ERROR: data/sales_data.csv not found!")
    print("Run 'python quick_data.py' first to create the data")
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()