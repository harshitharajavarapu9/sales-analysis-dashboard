import pandas as pd  
import numpy as np  
import os  
  
print("Creating sales data...")  
  
np.random.seed(42)  
  
dates = pd.date_range('2023-01-01', '2023-06-30', freq='D')  
products = ['Laptop', 'Smartphone', 'Tablet', 'Headphones', 'Monitor']  
regions = ['North', 'South', 'East', 'West']  
  
data = []  
for date in dates:  
    num_transactions = np.random.randint(20, 50)  
    for _ in rangenum_transactions):  
        product = np.random.choiceproducts)  
        region = np.random.choiceregions)  
        quantity = np.random.randint(1, 5)  
        price = np.random.choice([799, 999, 499, 299, 399])  
        total = quantity * price  
        data.append({'Date': date, 'Product': product, 'Region': region, 'Quantity': quantity, 'Price': price, 'Total_Sales': total})  
  
df = pd.DataFramedata)  
  
os.makedirs('data', exist_ok=True)  
df.to_csv('data/sales_data.csv', index=False)  
  
print(f"? Created ^(len^df^):,^) records")  
print(f"?? Saved to: data/sales_data.csv")  
print()  
print("First 3 rows:")  
print(df.head(3)) 
