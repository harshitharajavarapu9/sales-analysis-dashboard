"""
SAMPLE DATA GENERATOR for Sales Analysis Dashboard
This script creates realistic sales data for analysis
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os

def generate_sales_data():
    print("📊 Generating sample sales data...")
    
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Generate dates for year 2023
    start_date = datetime(2023, 1, 1)
    end_date = datetime(2023, 12, 31)
    dates = pd.date_range(start=start_date, end=end_date, freq='D')
    
    # Define products with different price ranges
    products = [
        {'name': 'Laptop Pro', 'category': 'Electronics', 'base_price': 1299},
        {'name': 'Smartphone X', 'category': 'Electronics', 'base_price': 999},
        {'name': 'Tablet Lite', 'category': 'Electronics', 'base_price': 499},
        {'name': 'Wireless Headphones', 'category': 'Accessories', 'base_price': 199},
        {'name': 'Gaming Monitor', 'category': 'Electronics', 'base_price': 799},
        {'name': 'Keyboard Mechanical', 'category': 'Accessories', 'base_price': 129},
        {'name': 'Mouse Wireless', 'category': 'Accessories', 'base_price': 79},
        {'name': 'USB-C Hub', 'category': 'Accessories', 'base_price': 49},
        {'name': 'Laptop Stand', 'category': 'Accessories', 'base_price': 89},
        {'name': 'Webcam HD', 'category': 'Electronics', 'base_price': 149}
    ]
    
    # Define regions
    regions = ['North America', 'Europe', 'Asia Pacific', 'Latin America']
    
    # Generate sales data
    data = []
    
    for date in dates:
        # Generate 50-100 sales per day
        daily_sales = np.random.randint(50, 100)
        
        for _ in range(daily_sales):
            product = np.random.choice(products)
            region = np.random.choice(regions)
            
            # Add seasonal variation (higher sales in Nov-Dec)
            seasonal_factor = 1.0
            if date.month == 11:  # November
                seasonal_factor = 1.3
            elif date.month == 12:  # December
                seasonal_factor = 1.5
            elif date.month in [6, 7]:  # Summer months
                seasonal_factor = 1.1
            
            # Quantity sold (1-5 units)
            quantity = np.random.randint(1, 6)
            
            # Price variation (±10%)
            price_variation = np.random.uniform(0.9, 1.1)
            price = round(product['base_price'] * price_variation, 2)
            
            # Calculate total
            total_sales = quantity * price
            
            # Add promotion flag (10% of sales)
            on_promotion = np.random.random() < 0.1
            
            data.append({
                'Date': date,
                'Product': product['name'],
                'Category': product['category'],
                'Region': region,
                'Quantity': quantity,
                'Unit_Price': price,
                'Total_Sales': total_sales,
                'On_Promotion': on_promotion,
                'Customer_ID': f"CUST{np.random.randint(10000, 99999)}"
            })
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Create data directory if it doesn't exist
    os.makedirs('data', exist_ok=True)
    
    # Save to CSV
    csv_path = 'data/raw_sales_data.csv'
    df.to_csv(csv_path, index=False)
    
    # Also save to Excel
    excel_path = 'data/raw_sales_data.xlsx'
    df.to_excel(excel_path, index=False)
    
    # Print summary
    print(f"\n✅ Data generated successfully!")
    print(f"   Records: {len(df):,}")
    print(f"   Date Range: {df['Date'].min().date()} to {df['Date'].max().date()}")
    print(f"   Total Sales: ${df['Total_Sales'].sum():,.2f}")
    print(f"   Products: {df['Product'].nunique()}")
    print(f"   Regions: {', '.join(df['Region'].unique())}")
    print(f"\n📁 Files saved:")
    print(f"   {csv_path}")
    print(f"   {excel_path}")
    
    # Show sample of data
    print(f"\n📋 Sample data (first 5 rows):")
    print(df.head().to_string())
    
    return df

if __name__ == "__main__":
    generate_sales_data()