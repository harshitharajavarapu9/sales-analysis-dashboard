"""
EXCEL DASHBOARD CREATOR - FIXED VERSION
Creates an Excel file with sales analysis and charts
"""

import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.chart import BarChart, PieChart, Reference
from openpyxl.utils import get_column_letter
import os

print("📊 Creating Excel Dashboard...")

try:
    # Load data
    df = pd.read_csv('data/sales_data.csv')
    df['Date'] = pd.to_datetime(df['Date'])
    
    # Create outputs folder
    os.makedirs('outputs', exist_ok=True)
    
    # Create workbook
    wb = Workbook()
    
    # ===== SHEET 1: RAW DATA =====
    ws1 = wb.active
    ws1.title = "Raw Sales Data"
    
    # Add title
    ws1.merge_cells('A1:F1')
    title_cell = ws1['A1']
    title_cell.value = "SALES DATA - RAW TRANSACTIONS"
    title_cell.font = Font(size=14, bold=True, color="FFFFFF")
    title_cell.alignment = Alignment(horizontal='center')
    title_cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    
    # Write headers
    headers = list(df.columns)
    for col_num, header in enumerate(headers, 1):
        cell = ws1.cell(row=2, column=col_num)
        cell.value = header
        cell.font = Font(bold=True)
        cell.fill = PatternFill(start_color="DDEBF7", end_color="DDEBF7", fill_type="solid")
        cell.border = Border(bottom=Side(style='thin'))
    
    # Write data
    for row_num, row in enumerate(df.itertuples(index=False), 3):
        for col_num, value in enumerate(row, 1):
            cell = ws1.cell(row=row_num, column=col_num)
            cell.value = value
            
            # Format numbers
            if headers[col_num-1] in ['Price', 'Total_Sales']:
                cell.number_format = '$#,##0.00'
    
    # Auto-adjust column widths (FIXED)
    for col in range(1, len(headers) + 1):
        max_length = 0
        column_letter = get_column_letter(col)
        
        # Check header
        header_cell = ws1.cell(row=2, column=col)
        max_length = len(str(header_cell.value))
        
        # Check data rows
        for row in range(3, len(df) + 3):
            cell = ws1.cell(row=row, column=col)
            try:
                cell_length = len(str(cell.value))
                if cell_length > max_length:
                    max_length = cell_length
            except:
                pass
        
        # Set width
        adjusted_width = min(max_length + 2, 30)
        ws1.column_dimensions[column_letter].width = adjusted_width
    
    # ===== SHEET 2: ANALYSIS =====
    ws2 = wb.create_sheet("Analysis Dashboard")
    
    # Dashboard Title
    ws2.merge_cells('A1:E1')
    title_cell = ws2['A1']
    title_cell.value = "SALES ANALYSIS DASHBOARD"
    title_cell.font = Font(size=16, bold=True, color="FFFFFF")
    title_cell.alignment = Alignment(horizontal='center')
    title_cell.fill = PatternFill(start_color="4F81BD", end_color="4F81BD", fill_type="solid")
    
    # Summary Statistics
    ws2['A3'] = "SUMMARY STATISTICS"
    ws2['A3'].font = Font(size=12, bold=True)
    
    summary_data = [
        ["Total Transactions:", len(df)],
        ["Date Range:", f"{df['Date'].min().date()} to {df['Date'].max().date()}"],
        ["Total Revenue:", f"${df['Total_Sales'].sum():,.2f}"],
        ["Average Transaction:", f"${df['Total_Sales'].mean():,.2f}"],
        ["Unique Products:", df['Product'].nunique()],
        ["Regions:", df['Region'].nunique()]
    ]
    
    for i, (label, value) in enumerate(summary_data, start=4):
        ws2[f'A{i}'] = label
        ws2[f'B{i}'] = value
        ws2[f'A{i}'].font = Font(bold=True)
    
    # ===== SHEET 3: MONTHLY ANALYSIS =====
    ws3 = wb.create_sheet("Monthly Analysis")
    
    # Calculate monthly sales
    df['Month'] = df['Date'].dt.month_name()
    monthly_sales = df.groupby('Month')['Total_Sales'].sum().reset_index()
    
    ws3['A1'] = "MONTHLY SALES TREND"
    ws3['A1'].font = Font(size=12, bold=True)
    
    ws3['A2'] = "Month"
    ws3['B2'] = "Total Sales"
    ws3['A2'].font = ws3['B2'].font = Font(bold=True)
    
    for i, (month, sales) in enumerate(zip(monthly_sales['Month'], monthly_sales['Total_Sales']), start=3):
        ws3[f'A{i}'] = month
        ws3[f'B{i}'] = sales
        ws3[f'B{i}'].number_format = '$#,##0.00'
    
    # Create bar chart
    chart1 = BarChart()
    chart1.type = "col"
    chart1.style = 10
    chart1.title = "Monthly Sales Trend"
    chart1.y_axis.title = "Total Sales ($)"
    chart1.x_axis.title = "Month"
    
    data = Reference(ws3, min_col=2, min_row=2, max_row=len(monthly_sales)+2)
    cats = Reference(ws3, min_col=1, min_row=3, max_row=len(monthly_sales)+2)
    chart1.add_data(data, titles_from_data=False)
    chart1.set_categories(cats)
    
    ws3.add_chart(chart1, "D2")
    
    # ===== SHEET 4: PRODUCT ANALYSIS =====
    ws4 = wb.create_sheet("Product Analysis")
    
    # Calculate product sales
    product_sales = df.groupby('Product').agg({
        'Quantity': 'sum',
        'Total_Sales': 'sum'
    }).reset_index().sort_values('Total_Sales', ascending=False)
    
    ws4['A1'] = "PRODUCT PERFORMANCE"
    ws4['A1'].font = Font(size=12, bold=True)
    
    headers = ["Product", "Quantity Sold", "Total Revenue"]
    for col, header in enumerate(headers, 1):
        cell = ws4.cell(row=2, column=col)
        cell.value = header
        cell.font = Font(bold=True)
    
    for i, row in product_sales.iterrows():
        ws4[f'A{i+3}'] = row['Product']
        ws4[f'B{i+3}'] = row['Quantity']
        ws4[f'C{i+3}'] = row['Total_Sales']
        ws4[f'C{i+3}'].number_format = '$#,##0.00'
    
    # Create horizontal bar chart
    chart2 = BarChart()
    chart2.type = "bar"
    chart2.style = 11
    chart2.title = "Revenue by Product"
    chart2.x_axis.title = "Total Sales ($)"
    
    data = Reference(ws4, min_col=3, min_row=2, max_row=len(product_sales)+2)
    cats = Reference(ws4, min_col=1, min_row=3, max_row=len(product_sales)+2)
    chart2.add_data(data, titles_from_data=False)
    chart2.set_categories(cats)
    
    ws4.add_chart(chart2, "E2")
    
    # ===== SHEET 5: REGIONAL ANALYSIS =====
    ws5 = wb.create_sheet("Regional Analysis")
    
    # Calculate regional sales
    region_sales = df.groupby('Region')['Total_Sales'].sum().reset_index().sort_values('Total_Sales', ascending=False)
    
    ws5['A1'] = "REGIONAL SALES"
    ws5['A1'].font = Font(size=12, bold=True)
    
    ws5['A2'] = "Region"
    ws5['B2'] = "Total Sales"
    ws5['A2'].font = ws5['B2'].font = Font(bold=True)
    
    for i, row in region_sales.iterrows():
        ws5[f'A{i+3}'] = row['Region']
        ws5[f'B{i+3}'] = row['Total_Sales']
        ws5[f'B{i+3}'].number_format = '$#,##0.00'
    
    # Create pie chart
    chart3 = PieChart()
    chart3.title = "Sales Distribution by Region"
    
    data = Reference(ws5, min_col=2, min_row=2, max_row=len(region_sales)+2)
    labels = Reference(ws5, min_col=1, min_row=3, max_row=len(region_sales)+2)
    chart3.add_data(data, titles_from_data=False)
    chart3.set_categories(labels)
    
    ws5.add_chart(chart3, "D2")
    
    # Save workbook
    output_path = 'outputs/sales_dashboard.xlsx'
    wb.save(output_path)
    
    print(f"✅ Excel Dashboard created successfully!")
    print(f"📁 Saved to: {output_path}")
    print(f"\n📊 Workbook contains:")
    print(f"   1. Raw Sales Data - {len(df):,} transactions")
    print(f"   2. Analysis Dashboard - Summary statistics")
    print(f"   3. Monthly Analysis - Trends and bar chart")
    print(f"   4. Product Analysis - Rankings and bar chart")
    print(f"   5. Regional Analysis - Distribution and pie chart")
    print(f"\n💡 Open {output_path} in Microsoft Excel to view interactive dashboard")
    
except FileNotFoundError:
    print("❌ ERROR: data/sales_data.csv not found!")
    print("Run 'python quick_data.py' first to create the data")
except ImportError as e:
    print(f"❌ ERROR: {e}")
    print("Install openpyxl: pip install openpyxl")
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()